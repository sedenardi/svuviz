'use strict';

var svuviz = require('./svuviz');

svuviz.runBaseTitles();
