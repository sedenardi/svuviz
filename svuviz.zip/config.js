'use strict';

const path = require('path');
const _ = require('lodash');
const AWS = require('aws-sdk');

const env = process.env.NODE_ENV || 'production';

const base = {
  app: {
    root: path.normalize(path.join(__dirname, '/..')),
    env: env,
  },
};

const specific = {
  production: {
    app: {
      host: 'localhost',
      port: 3002,
      name: 'Svuviz',
      folders: {
        static: 'web',
        views: 'web/views'
      }
    },
    mysql: {
      host: 'public-db.ckcazcxof67o.us-east-1.rds.amazonaws.com',
      user: 'sanders',
      password: 'S4nd3rs12',
      database: 'svuviz',
      multipleStatements: true,
      timezone: 'Z'
    },
    AWS: function() {
      AWS.config.update({
        accessKeyId: 'AKIAJ2VOXOUOJSVMHMTQ',
        secretAccessKey: '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',
        region: 'us-east-1'
      });
      // AWS.config.update({
      //   region: 'us-east-1'
      // });
      return AWS;
    },
    S3: {
      Bucket: 'nerdshit.net',
      Folder: 'svuviz',
      ACL: 'public-read'
    }
  }
};

module.exports = _.merge(base, specific[env]);
