INSERT IGNORE INTO `BaseTitles` 
VALUES
  ('tt0203259','SVUViz',1),
  ('tt0108778','FriendsViz',2),
  ('tt0098904','SeinfeldViz',3);

