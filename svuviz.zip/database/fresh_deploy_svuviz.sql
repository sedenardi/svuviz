SET FOREIGN_KEY_CHECKS=0;
CREATE DATABASE svuviz CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;;
USE svuviz;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Actors` (
  `ActorID` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Birthday` date DEFAULT NULL,
  `RecordedOn` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ActorID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Appearances` (
  `AppearanceID` int(11) NOT NULL AUTO_INCREMENT,
  `ActorID` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `TitleID` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Character` text COLLATE utf8mb4_unicode_ci,
  `CharacterID` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `RecordedOn` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`AppearanceID`),
  KEY `idx_Appearances_Actor` (`ActorID`),
  KEY `idx_Appearances_Title` (`TitleID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BaseTitles` (
  `BaseTitleID` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `DisplayName` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Sort` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CommonTitleActors` (
  `ParentTitleID` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `TitleID` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `ActorID` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ParentTitleID`,`TitleID`,`ActorID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ProcessActors` (
  `ActorID` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ProcessTitles` (
  `TitleID` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Titles` (
  `TitleID` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ParentTitleID` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Season` tinyint(4) DEFAULT NULL,
  `Number` tinyint(4) DEFAULT NULL,
  `Title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Synopsis` text COLLATE utf8mb4_unicode_ci,
  `AirDate` date DEFAULT NULL,
  `Year` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `RecordedOn` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`TitleID`),
  KEY `idx_Titles_ParentTitleID_AirDate` (`ParentTitleID`,`AirDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT IGNORE INTO `BaseTitles` 
VALUES
  ('tt0203259','SVUViz',1),
  ('tt0108778','FriendsViz',2),
  ('tt0098904','SeinfeldViz',3);

